package com.company;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class Consumidor extends Thread {
    int id;
    boolean bandera = true;
    Almacen almacen;
    long tiempo;

    Consumidor(int id, Almacen almacen) {
        this.id = id;
        this.almacen = almacen;
    }

    @Override
    public void run() {
        System.out.println("Consumidor " + this.id);
        String producto = this.almacen.consumir();

        this.tiempo = System.currentTimeMillis();

        while (almacen.isProducing()) {

            System.out.println("[" + this.id + "] Consume: " + producto);

            ProcessBuilder pb = new ProcessBuilder();
            pb.directory(new File("/Users/oscar/Local/compu-methods/actividad_3_4"));
            pb.command("./a.out", "3", producto);

            try {
                Process process = pb.start();
                int ret = process.waitFor();

                System.out.printf("[%s] a.out exited with code: %d\n", this.id, ret);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }

            almacen.addTiempo(this.id, System.currentTimeMillis() - this.tiempo);
            System.out.println("Max time for [" + this.id + "]: " + almacen.getMaxTime() + "ms");

            producto = this.almacen.consumir();

            almacen.addTiempo(this.id, System.currentTimeMillis() - this.tiempo);
            System.out.println("Max time for [" + this.id + "]: " + almacen.getMaxTime() + "ms");
        }
    }

    public void detener() {
        this.bandera = false;
    }
}
